/**
 * Dashboard Interactive Features
 * 
 * This script implements the core interactive features for the Lead Intelligence Dashboard,
 * including navigation, data visualization, and interactive elements.
 */

document.addEventListener('DOMContentLoaded', function() {
    // Global elements
    const sidePanel = document.getElementById('side-panel');
    const sidePanelToggle = document.getElementById('side-panel-toggle');
    const sidePanelClose = document.getElementById('side-panel-close');
    const notificationBell = document.querySelector('.notification-btn');
    const notificationPanel = document.getElementById('notification-panel');
    const searchInput = document.querySelector('.search-input');
    const searchResults = document.getElementById('search-results');
    const dateFilters = document.querySelectorAll('.date-filter-btn');
    const themeToggle = document.getElementById('theme-toggle');
    
    // Initialize charts if they exist
    initializeCharts();
    
    // Side Panel Toggle
    if (sidePanelToggle && sidePanel) {
        sidePanelToggle.addEventListener('click', function() {
            sidePanel.classList.toggle('active');
        });
    }
    
    if (sidePanelClose && sidePanel) {
        sidePanelClose.addEventListener('click', function() {
            sidePanel.classList.remove('active');
        });
    }
    
    // Notification Panel Toggle
    if (notificationBell && notificationPanel) {
        notificationBell.addEventListener('click', function(e) {
            e.stopPropagation();
            notificationPanel.classList.toggle('active');
            
            // Mark as read when opened
            const badge = notificationBell.querySelector('.notification-badge');
            if (badge) {
                badge.style.display = 'none';
            }
        });
        
        // Close notification panel when clicking outside
        document.addEventListener('click', function(e) {
            if (notificationPanel.classList.contains('active') && 
                !notificationPanel.contains(e.target) && 
                e.target !== notificationBell) {
                notificationPanel.classList.remove('active');
            }
        });
    }
    
    // Search functionality
    if (searchInput && searchResults) {
        searchInput.addEventListener('focus', function() {
            searchResults.classList.add('active');
        });
        
        searchInput.addEventListener('blur', function() {
            setTimeout(() => {
                searchResults.classList.remove('active');
            }, 200);
        });
        
        searchInput.addEventListener('input', function() {
            if (this.value.length > 2) {
                // Simulate search results
                searchResults.innerHTML = `
                    <div class="search-category">
                        <div class="category-title">Leads</div>
                        <div class="search-item">
                            <div class="item-icon">👤</div>
                            <div class="item-content">
                                <div class="item-title">John Smith</div>
                                <div class="item-subtitle">Acme Corporation</div>
                            </div>
                        </div>
                        <div class="search-item">
                            <div class="item-icon">👤</div>
                            <div class="item-content">
                                <div class="item-title">Sarah Johnson</div>
                                <div class="item-subtitle">TechGiant Solutions</div>
                            </div>
                        </div>
                    </div>
                    <div class="search-category">
                        <div class="category-title">Companies</div>
                        <div class="search-item">
                            <div class="item-icon">🏢</div>
                            <div class="item-content">
                                <div class="item-title">Acme Corporation</div>
                                <div class="item-subtitle">Technology</div>
                            </div>
                        </div>
                    </div>
                    <div class="search-category">
                        <div class="category-title">Tasks</div>
                        <div class="search-item">
                            <div class="item-icon">📋</div>
                            <div class="item-content">
                                <div class="item-title">Follow up with John Smith</div>
                                <div class="item-subtitle">Due tomorrow</div>
                            </div>
                        </div>
                    </div>
                `;
                searchResults.classList.add('active');
            } else {
                searchResults.innerHTML = '';
                searchResults.classList.remove('active');
            }
        });
    }
    
    // Date filter functionality
    if (dateFilters.length > 0) {
        dateFilters.forEach(filter => {
            filter.addEventListener('click', function() {
                dateFilters.forEach(f => f.classList.remove('active'));
                this.classList.add('active');
                
                // Trigger data refresh based on selected date range
                refreshDashboardData(this.textContent.trim());
            });
        });
    }
    
    // Theme toggle
    if (themeToggle) {
        themeToggle.addEventListener('click', function() {
            document.body.classList.toggle('dark-mode');
            
            // Save preference
            const isDarkMode = document.body.classList.contains('dark-mode');
            localStorage.setItem('darkMode', isDarkMode);
            
            // Update icon
            this.textContent = isDarkMode ? '☀️' : '🌙';
        });
        
        // Check saved preference
        const savedDarkMode = localStorage.getItem('darkMode') === 'true';
        if (savedDarkMode) {
            document.body.classList.add('dark-mode');
            themeToggle.textContent = '☀️';
        }
    }
    
    // Initialize interactive tables
    initializeTables();
    
    // Initialize lead cards
    initializeLeadCards();
    
    // Initialize tooltips
    initializeTooltips();
    
    // Initialize drag and drop for kanban boards if they exist
    initializeKanban();
});

/**
 * Initialize data visualization charts
 */
function initializeCharts() {
    // Check if Chart.js is loaded
    if (typeof Chart === 'undefined') {
        console.warn('Chart.js not loaded. Skipping chart initialization.');
        return;
    }
    
    // Sample chart configurations
    
    // Lead Funnel Chart
    const funnelCanvas = document.getElementById('lead-funnel-chart');
    if (funnelCanvas) {
        const funnelChart = new Chart(funnelCanvas, {
            type: 'bar',
            data: {
                labels: ['Leads', 'Qualified', 'Meeting', 'Proposal', 'Negotiation', 'Closed'],
                datasets: [{
                    label: 'Lead Funnel',
                    data: [247, 186, 124, 78, 42, 18],
                    backgroundColor: [
                        'rgba(72, 149, 239, 0.8)',
                        'rgba(72, 149, 239, 0.7)',
                        'rgba(72, 149, 239, 0.6)',
                        'rgba(72, 149, 239, 0.5)',
                        'rgba(72, 149, 239, 0.4)',
                        'rgba(72, 149, 239, 0.3)'
                    ],
                    borderColor: [
                        'rgba(72, 149, 239, 1)',
                        'rgba(72, 149, 239, 1)',
                        'rgba(72, 149, 239, 1)',
                        'rgba(72, 149, 239, 1)',
                        'rgba(72, 149, 239, 1)',
                        'rgba(72, 149, 239, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                indexAxis: 'y',
                scales: {
                    x: {
                        beginAtZero: true
                    }
                }
            }
        });
    }
    
    // Lead Source Chart
    const sourceCanvas = document.getElementById('lead-source-chart');
    if (sourceCanvas) {
        const sourceChart = new Chart(sourceCanvas, {
            type: 'doughnut',
            data: {
                labels: ['Website', 'Referral', 'Social Media', 'Event', 'Email', 'Other'],
                datasets: [{
                    label: 'Lead Sources',
                    data: [35, 25, 15, 10, 10, 5],
                    backgroundColor: [
                        'rgba(67, 97, 238, 0.8)',
                        'rgba(72, 149, 239, 0.8)',
                        'rgba(76, 201, 240, 0.8)',
                        'rgba(247, 37, 133, 0.8)',
                        'rgba(248, 150, 30, 0.8)',
                        'rgba(108, 117, 125, 0.8)'
                    ],
                    borderColor: [
                        'rgba(67, 97, 238, 1)',
                        'rgba(72, 149, 239, 1)',
                        'rgba(76, 201, 240, 1)',
                        'rgba(247, 37, 133, 1)',
                        'rgba(248, 150, 30, 1)',
                        'rgba(108, 117, 125, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'right',
                    }
                }
            }
        });
    }
    
    // Lead Activity Chart
    const activityCanvas = document.getElementById('lead-activity-chart');
    if (activityCanvas) {
        const activityChart = new Chart(activityCanvas, {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                datasets: [{
                    label: 'New Leads',
                    data: [65, 78, 52, 91, 85, 107],
                    borderColor: 'rgba(67, 97, 238, 1)',
                    backgroundColor: 'rgba(67, 97, 238, 0.1)',
                    tension: 0.3,
                    fill: true
                }, {
                    label: 'Conversions',
                    data: [28, 32, 21, 37, 43, 52],
                    borderColor: 'rgba(76, 201, 240, 1)',
                    backgroundColor: 'rgba(76, 201, 240, 0.1)',
                    tension: 0.3,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }
    
    // Revenue Forecast Chart
    const forecastCanvas = document.getElementById('revenue-forecast-chart');
    if (forecastCanvas) {
        const forecastChart = new Chart(forecastCanvas, {
            type: 'line',
            data: {
                labels: ['Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                datasets: [{
                    label: 'Projected Revenue',
                    data: [250000, 320000, 380000, 410000, 390000, 450000],
                    borderColor: 'rgba(67, 97, 238, 1)',
                    backgroundColor: 'rgba(67, 97, 238, 0.1)',
                    tension: 0.3,
                    fill: true
                }, {
                    label: 'Actual Revenue',
                    data: [240000, 310000, 360000, null, null, null],
                    borderColor: 'rgba(76, 201, 240, 1)',
                    backgroundColor: 'rgba(76, 201, 240, 0.1)',
                    tension: 0.3,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return '$' + value.toLocaleString();
                            }
                        }
                    }
                },
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return context.dataset.label + ': $' + context.raw.toLocaleString();
                            }
                        }
                    }
                }
            }
        });
    }
    
    // Team Performance Chart
    const teamCanvas = document.getElementById('team-performance-chart');
    if (teamCanvas) {
        const teamChart = new Chart(teamCanvas, {
            type: 'radar',
            data: {
                labels: ['Lead Response', 'Follow-up', 'Qualification', 'Meetings', 'Proposals', 'Closing'],
                datasets: [{
                    label: 'Team Average',
                    data: [75, 85, 70, 80, 65, 60],
                    backgroundColor: 'rgba(67, 97, 238, 0.2)',
                    borderColor: 'rgba(67, 97, 238, 1)',
                    pointBackgroundColor: 'rgba(67, 97, 238, 1)',
                    pointBorderColor: '#fff',
                    pointHoverBackgroundColor: '#fff',
                    pointHoverBorderColor: 'rgba(67, 97, 238, 1)'
                }, {
                    label: 'Top Performer',
                    data: [90, 95, 85, 92, 88, 80],
                    backgroundColor: 'rgba(76, 201, 240, 0.2)',
                    borderColor: 'rgba(76, 201, 240, 1)',
                    pointBackgroundColor: 'rgba(76, 201, 240, 1)',
                    pointBorderColor: '#fff',
                    pointHoverBackgroundColor: '#fff',
                    pointHoverBorderColor: 'rgba(76, 201, 240, 1)'
                }]
            },
            options: {
                responsive: true,
                scales: {
                    r: {
                        angleLines: {
                            display: true
                        },
                        suggestedMin: 0,
                        suggestedMax: 100
                    }
                }
            }
        });
    }
    
    // Automation Performance Chart
    const automationCanvas = document.getElementById('automation-performance-chart');
    if (automationCanvas) {
        const automationChart = new Chart(automationCanvas, {
            type: 'line',
            data: {
                labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4'],
                datasets: [{
                    label: 'Tasks Automated',
                    data: [850, 920, 1050, 1180],
                    borderColor: 'rgba(67, 97, 238, 1)',
                    backgroundColor: 'rgba(67, 97, 238, 0.1)',
                    tension: 0.3,
                    fill: true,
                    yAxisID: 'y'
                }, {
                    label: 'Time Saved (hours)',
                    data: [8.5, 9.2, 10.5, 11.8],
                    borderColor: 'rgba(76, 201, 240, 1)',
                    backgroundColor: 'rgba(76, 201, 240, 0.1)',
                    tension: 0.3,
                    fill: true,
                    yAxisID: 'y1'
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        type: 'linear',
                        display: true,
                        position: 'left',
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Tasks Automated'
                        }
                    },
                    y1: {
                        type: 'linear',
                        display: true,
                        position: 'right',
                        beginAtZero: true,
                        grid: {
                            drawOnChartArea: false
                        },
                        title: {
                            display: true,
                            text: 'Time Saved (hours)'
                        }
                    }
                }
            }
        });
    }
}

/**
 * Initialize interactive tables
 */
function initializeTables() {
    const tables = document.querySelectorAll('.data-table');
    
    tables.forEach(table => {
        // Add sort functionality
        const headers = table.querySelectorAll('th[data-sort]');
        
        headers.forEach(header => {
            header.addEventListener('click', function() {
                const sortBy = this.dataset.sort;
                const sortDir = this.classList.contains('sort-asc') ? 'desc' : 'asc';
                
                // Reset all headers
                headers.forEach(h => {
                    h.classList.remove('sort-asc', 'sort-desc');
                });
                
                // Set current header
                this.classList.add(`sort-${sortDir}`);
                
                // Sort table
                sortTable(table, sortBy, sortDir);
            });
        });
        
        // Add search functionality
        const tableSearch = table.parentElement.querySelector('.table-search');
        if (tableSearch) {
            tableSearch.addEventListener('input', function() {
                const searchTerm = this.value.toLowerCase();
                const rows = table.querySelectorAll('tbody tr');
                
                rows.forEach(row => {
                    const text = row.textContent.toLowerCase();
                    row.style.display = text.includes(searchTerm) ? '' : 'none';
                });
            });
        }
        
        // Add pagination if needed
        const pagination = table.parentElement.querySelector('.table-pagination');
        if (pagination) {
            const rowsPerPage = parseInt(table.dataset.rowsPerPage || 10);
            const rows = table.querySelectorAll('tbody tr');
            const pageCount = Math.ceil(rows.length / rowsPerPage);
            
            // Create pagination buttons
            pagination.innerHTML = '';
            
            const prevBtn = document.createElement('button');
            prevBtn.className = 'pagination-btn prev';
            prevBtn.textContent = '←';
            prevBtn.disabled = true;
            pagination.appendChild(prevBtn);
            
            for (let i = 1; i <= pageCount; i++) {
                const pageBtn = document.createElement('button');
                pageBtn.className = 'pagination-btn page';
                pageBtn.textContent = i;
                pageBtn.dataset.page = i;
                
                if (i === 1) {
                    pageBtn.classList.add('active');
                }
                
                pagination.appendChild(pageBtn);
            }
            
            const nextBtn = document.createElement('button');
            nextBtn.className = 'pagination-btn next';
            nextBtn.textContent = '→';
            pagination.appendChild(nextBtn);
            
            // Show first page
            showTablePage(table, 1, rowsPerPage);
            
            // Add event listeners
            pagination.addEventListener('click', function(e) {
                if (e.target.classList.contains('page')) {
                    const page = parseInt(e.target.dataset.page);
                    
                    // Update active button
                    pagination.querySelectorAll('.page').forEach(btn => {
                        btn.classList.remove('active');
                    });
                    e.target.classList.add('active');
                    
                    // Update prev/next buttons
                    prevBtn.disabled = page === 1;
                    nextBtn.disabled = page === pageCount;
                    
                    // Show page
                    showTablePage(table, page, rowsPerPage);
                } else if (e.target.classList.contains('prev')) {
                    const activePage = pagination.querySelector('.page.active');
                    const page = parseInt(activePage.dataset.page) - 1;
                    
                    if (page >= 1) {
                        // Update active button
                        pagination.querySelectorAll('.page').forEach(btn => {
                            btn.classList.remove('active');
                        });
                        pagination.querySelector(`[data-page="${page}"]`).classList.add('active');
                        
                        // Update prev/next buttons
                        prevBtn.disabled = page === 1;
                        nextBtn.disabled = false;
                        
                        // Show page
                        showTablePage(table, page, rowsPerPage);
                    }
                } else if (e.target.classList.contains('next')) {
                    const activePage = pagination.querySelector('.page.active');
                    const page = parseInt(activePage.dataset.page) + 1;
                    
                    if (page <= pageCount) {
                        // Update active button
                        pagination.querySelectorAll('.page').forEach(btn => {
                            btn.classList.remove('active');
                        });
                        pagination.querySelector(`[data-page="${page}"]`).classList.add('active');
                        
                        // Update prev/next buttons
                        prevBtn.disabled = false;
                        nextBtn.disabled = page === pageCount;
                        
                        // Show page
                        showTablePage(table, page, rowsPerPage);
                    }
                }
            });
        }
    });
}

/**
 * Sort table by column
 */
function sortTable(table, sortBy, sortDir) {
    const tbody = table.querySelector('tbody');
    const rows = Array.from(tbody.querySelectorAll('tr'));
    
    // Sort rows
    rows.sort((a, b) => {
        const aValue = a.querySelector(`[data-value="${sortBy}"]`)?.dataset.rawValue || 
                      a.querySelector(`td:nth-child(${getColumnIndex(table, sortBy) + 1})`)?.textContent;
        
        const bValue = b.querySelector(`[data-value="${sortBy}"]`)?.dataset.rawValue || 
                      b.querySelector(`td:nth-child(${getColumnIndex(table, sortBy) + 1})`)?.textContent;
        
        // Check if values are numbers
        const aNum = parseFloat(aValue);
        const bNum = parseFloat(bValue);
        
        if (!isNaN(aNum) && !isNaN(bNum)) {
            return sortDir === 'asc' ? aNum - bNum : bNum - aNum;
        }
        
        // Sort as strings
        return sortDir === 'asc' ? 
            aValue.localeCompare(bValue) : 
            bValue.localeCompare(aValue);
    });
    
    // Reorder rows
    rows.forEach(row => {
        tbody.appendChild(row);
    });
}

/**
 * Get column index by name
 */
function getColumnIndex(table, columnName) {
    const headers = table.querySelectorAll('th');
    
    for (let i = 0; i < headers.length; i++) {
        if (headers[i].dataset.sort === columnName) {
            return i;
        }
    }
    
    return 0;
}

/**
 * Show table page
 */
function showTablePage(table, page, rowsPerPage) {
    const rows = table.querySelectorAll('tbody tr');
    const startIndex = (page - 1) * rowsPerPage;
    const endIndex = startIndex + rowsPerPage;
    
    rows.forEach((row, index) => {
        row.style.display = (index >= startIndex && index < endIndex) ? '' : 'none';
    });
}

/**
 * Initialize lead cards
 */
function initializeLeadCards() {
    const leadCards = document.querySelectorAll('.lead-card');
    
    leadCards.forEach(card => {
        // Add click event to expand/collapse details
        const header = card.querySelector('.lead-card-header');
        const details = card.querySelector('.lead-card-details');
        
        if (header && details) {
            header.addEventListener('click', function() {
                details.classList.toggle('active');
                card.classList.toggle('expanded');
            });
        }
        
        // Add action buttons functionality
        const actionButtons = card.querySelectorAll('.lead-action');
        
        actionButtons.forEach(button => {
            button.addEventListener('click', function(e) {
                e.stopPropagation();
                
                const action = this.dataset.action;
                const leadId = card.dataset.leadId;
                
                // Handle different actions
                switch (action) {
                    case 'call':
                        showNotification(`Calling lead ${leadId}...`, 'info');
                        break;
                    case 'email':
                        showNotification(`Opening email composer for lead ${leadId}...`, 'info');
                        break;
                    case 'task':
                        showNotification(`Creating task for lead ${leadId}...`, 'info');
                        break;
                    case 'note':
                        showNotification(`Adding note to lead ${leadId}...`, 'info');
                        break;
                    case 'qualify':
                        card.classList.add('qualified');
                        showNotification(`Lead ${leadId} marked as qualified`, 'success');
                        break;
                    case 'disqualify':
                        card.classList.add('disqualified');
                        showNotification(`Lead ${leadId} marked as disqualified`, 'warning');
                        break;
                }
            });
        });
    });
}

/**
 * Initialize tooltips
 */
function initializeTooltips() {
    const tooltipElements = document.querySelectorAll('[data-tooltip]');
    
    tooltipElements.forEach(element => {
        element.addEventListener('mouseenter', function() {
            const tooltipText = this.dataset.tooltip;
            
            const tooltip = document.createElement('div');
            tooltip.className = 'tooltip';
            tooltip.textContent = tooltipText;
            
            document.body.appendChild(tooltip);
            
            const rect = this.getBoundingClientRect();
            const tooltipRect = tooltip.getBoundingClientRect();
            
            tooltip.style.top = `${rect.top - tooltipRect.height - 10}px`;
            tooltip.style.left = `${rect.left + (rect.width / 2) - (tooltipRect.width / 2)}px`;
            
            tooltip.classList.add('active');
            
            this.addEventListener('mouseleave', function onMouseLeave() {
                tooltip.remove();
                this.removeEventListener('mouseleave', onMouseLeave);
            });
        });
    });
}

/**
 * Initialize kanban boards
 */
function initializeKanban() {
    const kanbanBoards = document.querySelectorAll('.kanban-board');
    
    kanbanBoards.forEach(board => {
        const columns = board.querySelectorAll('.kanban-column');
        
        columns.forEach(column => {
            column.addEventListener('dragover', function(e) {
                e.preventDefault();
                this.classList.add('drag-over');
            });
            
            column.addEventListener('dragleave', function() {
                this.classList.remove('drag-over');
            });
            
            column.addEventListener('drop', function(e) {
                e.preventDefault();
                this.classList.remove('drag-over');
                
                const cardId = e.dataTransfer.getData('text/plain');
                const card = document.getElementById(cardId);
                
                if (card) {
                    this.querySelector('.kanban-cards').appendChild(card);
                    
                    // Update card status
                    const newStatus = this.dataset.status;
                    card.dataset.status = newStatus;
                    
                    // Show notification
                    showNotification(`Card moved to ${this.querySelector('.column-title').textContent}`, 'success');
                    
                    // Update counters
                    updateKanbanCounters(board);
                }
            });
        });
        
        const cards = board.querySelectorAll('.kanban-card');
        
        cards.forEach(card => {
            card.setAttribute('draggable', true);
            
            card.addEventListener('dragstart', function(e) {
                e.dataTransfer.setData('text/plain', this.id);
                this.classList.add('dragging');
            });
            
            card.addEventListener('dragend', function() {
                this.classList.remove('dragging');
            });
        });
        
        // Initialize counters
        updateKanbanCounters(board);
    });
}

/**
 * Update kanban column counters
 */
function updateKanbanCounters(board) {
    const columns = board.querySelectorAll('.kanban-column');
    
    columns.forEach(column => {
        const counter = column.querySelector('.column-counter');
        const cards = column.querySelectorAll('.kanban-card');
        
        if (counter) {
            counter.textContent = cards.length;
        }
    });
}

/**
 * Refresh dashboard data based on date range
 */
function refreshDashboardData(dateRange) {
    // Show loading indicator
    showNotification(`Loading data for ${dateRange} view...`, 'info');
    
    // Simulate data refresh
    setTimeout(() => {
        // Update charts if they exist
        updateCharts(dateRange);
        
        // Update metrics
        updateMetrics(dateRange);
        
        // Show success notification
        showNotification(`Dashboard updated with ${dateRange} data`, 'success');
    }, 1000);
}

/**
 * Update charts based on date range
 */
function updateCharts(dateRange) {
    // Check if Chart.js is loaded
    if (typeof Chart === 'undefined') {
        return;
    }
    
    // Get all charts
    const charts = Chart.instances;
    
    // Update each chart with new data
    charts.forEach(chart => {
        // Generate random data based on date range
        const data = chart.data.datasets.map(dataset => {
            return dataset.data.map(value => {
                // Add some random variation
                const variation = Math.random() * 0.3 - 0.15; // -15% to +15%
                return Math.round(value * (1 + variation));
            });
        });
        
        // Update chart data
        chart.data.datasets.forEach((dataset, i) => {
            dataset.data = data[i];
        });
        
        // Update chart
        chart.update();
    });
}

/**
 * Update metrics based on date range
 */
function updateMetrics(dateRange) {
    // Get all metric values
    const metricValues = document.querySelectorAll('.metric-value');
    
    // Update each metric with new data
    metricValues.forEach(metric => {
        const currentValue = parseFloat(metric.textContent.replace(/[^0-9.-]+/g, ''));
        
        // Add some random variation
        const variation = Math.random() * 0.2 - 0.1; // -10% to +10%
        let newValue = currentValue * (1 + variation);
        
        // Format based on content
        if (metric.textContent.includes('%')) {
            newValue = newValue.toFixed(1) + '%';
        } else if (metric.textContent.includes('$')) {
            newValue = '$' + newValue.toLocaleString(undefined, { maximumFractionDigits: 0 });
        } else if (Number.isInteger(currentValue)) {
            newValue = Math.round(newValue);
        } else {
            newValue = newValue.toFixed(1);
        }
        
        // Update metric
        metric.textContent = newValue;
        
        // Update trend if exists
        const trendElement = metric.parentElement.querySelector('.metric-trend, .trend-up, .trend-down');
        if (trendElement) {
            const isPositive = Math.random() > 0.5;
            const trendValue = (Math.random() * 15).toFixed(1);
            
            if (isPositive) {
                trendElement.className = trendElement.className.replace('trend-down', 'trend-up');
                trendElement.innerHTML = `<span class="trend-icon">↑</span> ${trendValue}% from last ${dateRange.toLowerCase()}`;
            } else {
                trendElement.className = trendElement.className.replace('trend-up', 'trend-down');
                trendElement.innerHTML = `<span class="trend-icon">↓</span> ${trendValue}% from last ${dateRange.toLowerCase()}`;
            }
        }
    });
}

/**
 * Show notification
 */
function showNotification(message, type) {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.classList.add('show');
    }, 10);
    
    setTimeout(() => {
        notification.classList.remove('show');
        
        setTimeout(() => {
            notification.remove();
        }, 300);
    }, 3000);
}
